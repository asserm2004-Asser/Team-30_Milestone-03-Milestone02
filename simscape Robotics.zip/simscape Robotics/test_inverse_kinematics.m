% ---------------------------------------------------------
% Test Script for inverse_kinematics_func(q0, X_des)
% ---------------------------------------------------------
clear; clc; close all;

disp('==============================================');
disp('     Testing Numerical Inverse Kinematics      ');
disp('==============================================');

%% 1. Robot link lengths (same values used in FK & IK)
L1 = 43.55;
L2 = 140;
L3 = 134;
L4 = 70;

%% 2. Build DH function used for FK (same as inside IK)
buildDH = @(q) [ ...
    (-pi/2 + q(1))  L1  0   -pi/2;  
    (-pi/2 + q(2))   0  L2   0;     
    (q(3))           0  L3   0;     
    (q(4))           0  L4   0 ];

%% 3. Choose a known joint configuration (ground truth)
q_true_deg = [20; 25; -10; 5]; 
q_true = deg2rad(q_true_deg);

fprintf('Ground Truth Joint Angles (deg): [%.1f %.1f %.1f %.1f]\n', q_true_deg);

%% 4. Compute desired end-effector position from FK
DH_true = buildDH(q_true);
[X_des, ~] = forward_kinematics_func_num(DH_true);

disp('Desired End-Effector Position (from FK):');
disp(X_des');

%% 5. Choose an initial guess for IK
q0_deg = [0; 0; 0; 0];
q0 = deg2rad(q0_deg);

fprintf('\nInitial Guess q0 (deg): [%.1f %.1f %.1f %.1f]\n', q0_deg);

%% 6. Solve IK numerically
q_sol = inverse_kinematics_func(q0, X_des);

disp('Solution Joint Angles (rad):');
disp(q_sol');

disp('Solution Joint Angles (deg):');
disp(rad2deg(q_sol)');

%% 7. Validate by computing FK again
DH_sol = buildDH(q_sol);
[X_sol, ~] = forward_kinematics_func_num(DH_sol);

disp('End-Effector Position from IK Solution:');
disp(X_sol');

%% 8. Compare desired vs achieved
disp('----------------------------------------------');
disp('Desired Position (X_des):');
disp(X_des');

disp('Achieved Position (X_sol):');
disp(X_sol');

disp('Position Error:');
disp((X_des - X_sol)');

disp('==============================================');
disp('         IK Test Completed Successfully        ');
disp('==============================================');
