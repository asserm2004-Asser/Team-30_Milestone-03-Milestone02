function J = jacobian_matrix(q)
% -----------------------------------------------------------
% jacobian_matrix(q):
%   Symbolic Jacobian of the 4-DOF robot
%
% Inputs:
%   q = [q1 q2 q3 q4]   (symbolic variables)
%
% Output:
%   J = 3x4 symbolic Jacobian matrix (dX/dq)
%
% -----------------------------------------------------------

    % Declare symbolic variables
    syms L1 L2 L3 L4 real

    % Assign your robot link lengths (mm or m)
    L1 = 43.55;
    L2 = 140;
    L3 = 134;
    L4 = 70;

    q1 = q(1);
    q2 = q(2);
    q3 = q(3);
    q4 = q(4);

    %% === DH TABLE (symbolic) ===
    DH = [ (-pi/2 + q1),   L1, 0,   -pi/2;
           (-pi/2 + q2),    0, L2,     0;
           q3,              0, L3,     0;
           q4,              0, L4,     0 ];

    %% === Compute symbolic FK ===
    T = sym(eye(4));
    for i = 1:4
        th = DH(i,1);
        d  = DH(i,2);
        a  = DH(i,3);
        al = DH(i,4);

        Ti = [ cos(th), -sin(th)*cos(al),  sin(th)*sin(al), a*cos(th);
               sin(th),  cos(th)*cos(al), -cos(th)*sin(al), a*sin(th);
                    0,            sin(al),           cos(al),        d;
                    0,                 0,                0,        1 ];
        T = T * Ti;
    end

    %% EE position (symbolic)
    X = T(1:3,4);     % [x; y; z]

    %% === Symbolic Jacobian ===
    J = jacobian(X, [q1 q2 q3 q4]);

end
