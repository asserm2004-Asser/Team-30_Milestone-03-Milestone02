function q_dot = inverse_velocity_kinematics(q, V_F)
% -----------------------------------------------------------
% inverse_velocity_kinematics:
%   Computes inverse velocity kinematics numerically.
%
% Inputs:
%   q   : [4x1] vector of joint angles (radians)
%   V_F : [3x1] desired end-effector linear velocity (m/s or mm/s)
%
% Output:
%   q_dot : [4x1] required joint velocities
%
% This function uses the pseudo-inverse Jacobian:
%       q_dot = J_inv(q) * V_F
%
% Requires:
%   - inverse_jacobian_matrix(q)
% -----------------------------------------------------------

    % Ensure vectors have correct shape
    q   = q(:);
    V_F = V_F(:);

    % Compute the pseudo-inverse Jacobian
    J_inv = inverse_jacobian_matrix(q);   % 4×3

    % Compute joint velocities
    q_dot = J_inv * V_F;

end
