% === Forward Kinematics Test Runner ===
clear; clc;

% Define your link lengths (meters)
L1 = 43.55;   % base–shoulder offset  0.04355
L2 = 140;   % upper arm length 0.140
L3 = 134;   % forearm length   0.134
L4 = 70;   % wrist–gripper offset 0.070

% Choose your joint angles (degrees) for each test later
buildDH = @(q) [ ...
    (-pi/2 + q(1))  L1  0   -pi/2;  % Joint 1 (waist)
    (-pi/2 + q(2))   0  L2  0;     % Joint 2 (shoulder)
    q(3)   0  L3  0;     % Joint 3 (elbow)
    q(4)   0  L4  0];    % Joint 4 (wrist)
qA_deg = [20 20 20 0];     % angles in degrees
qA = deg2rad(qA_deg);        % convert to radians

DH_A = buildDH(qA);
[X_A, T_A] = forward_kinematics_func_num(DH_A);

fprintf('Test A (Random angles):\n');
fprintf('q = [%.1f %.1f %.1f %.1f]°\n', qA_deg);
disp('End-effector position [m]:');
disp(X_A');
qB_deg = [0 0 0 0];
qB = deg2rad(qB_deg);

DH_B = buildDH(qB);
[X_B, T_B] = forward_kinematics_func_num(DH_B);

fprintf('\nTest B (All zeros):\n');
fprintf('q = [%.1f %.1f %.1f %.1f]°\n', qB_deg);
disp('End-effector position [m]:');
disp(X_B');

