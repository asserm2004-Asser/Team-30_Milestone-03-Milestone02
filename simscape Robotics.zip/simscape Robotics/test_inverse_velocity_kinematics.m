% ---------------------------------------------------------
% Test Script for Inverse Velocity Kinematics
% ---------------------------------------------------------
clear; clc; close all;

disp('===============================================');
disp('      TESTING INVERSE VELOCITY KINEMATICS      ');
disp('===============================================');

% Test joint angles (radians)
q = deg2rad([20; 15; -10; 5]);

% Desired end-effector velocity (example)
V_F = [10; 5; -2];    % units consistent with your FK (mm/s or m/s)

disp('Joint angles q (deg):');
disp(rad2deg(q)');

disp('Desired end-effector velocity V_F:');
disp(V_F');

% Compute joint velocities
q_dot = inverse_velocity_kinematics(q, V_F);

disp('-----------------------------------------------');
disp('Required joint velocities q_dot (rad/s):');
disp(q_dot');

disp('===============================================');
disp('  INVERSE VELOCITY KINEMATICS TEST COMPLETED   ');
disp('===============================================');
