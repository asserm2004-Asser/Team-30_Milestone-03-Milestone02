function V_F = forward_velocity_kinematics(q, q_dot)
% -----------------------------------------------------------
% forward_velocity_kinematics(q, q_dot):
%   Computes symbolic forward velocity of end-effector
%
% Inputs:
%   q      : symbolic joint variables  [q1 q2 q3 q4]
%   q_dot  : symbolic joint velocities [dq1 dq2 dq3 dq4]
%
% Output:
%   V_F : 3×1 symbolic Cartesian velocity vector
% -----------------------------------------------------------

    % Get symbolic Jacobian
    J = jacobian_matrix(q);

    % Velocity: V_F = J * q_dot
    V_F = J * q_dot(:);

end
