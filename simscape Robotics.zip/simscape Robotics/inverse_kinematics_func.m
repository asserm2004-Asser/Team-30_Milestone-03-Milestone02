function q = inverse_kinematics_func(q0, X_des)
% -----------------------------------------------------------
% inverse_kinematics_func:
%   Solves inverse POSITION kinematics numerically (Newton–Raphson)
%   for the 4-DOF robotic arm.
%
%   q  = inverse_kinematics_func(q0, X_des)
%
% Inputs:
%   q0    : [4x1] initial guess of joint angles (radians)
%   X_des : [3x1] desired end-effector position [x; y; z]
%           (same length units as used in forward_kinematics_func_num)
%
% Output:
%   q     : [4x1] joint angles (radians) that reach (or get close to) X_des
%
% Notes:
%   - Uses forward_kinematics_func_num(DH) from Milestone 02
%   - Uses inverse_jacobian_matrix(q) (pseudo-inverse Jacobian)
%   - Newton–Raphson iteration: q_{k+1} = q_k + J^+ * (X_des - X(q_k))
% -----------------------------------------------------------

    % Ensure column vectors
    q     = q0(:);
    X_des = X_des(:);

    % Robot link lengths (must match your FK & Jacobian code)
    L1 = 43.55;
    L2 = 140;
    L3 = 134;
    L4 = 70;

    % DH builder (same convention as before)
    buildDH = @(q) [ ...
        (-pi/2 + q(1))  L1  0   -pi/2;  
        (-pi/2 + q(2))   0  L2   0;     
        (q(3))           0  L3   0;     
        (q(4))           0  L4   0 ];

    % Iteration settings
    max_iter = 100;      % maximum number of iterations
    tol_pos  = 1e-3;     % position tolerance (same units as X)

    for k = 1:max_iter
        % ---- Forward kinematics: current end-effector position ----
        DH = buildDH(q);
        [X_curr, ~] = forward_kinematics_func_num(DH);   % [x; y; z]

        % ---- Position error ----
        e = X_des - X_curr;   % 3x1

        % Check convergence
        if norm(e) < tol_pos
            % Uncomment if you want to see convergence info:
            % fprintf('Converged in %d iterations.\n', k-1);
            return;
        end

        % ---- Compute pseudo-inverse Jacobian at current q ----
        J_inv = inverse_jacobian_matrix(q);  % 4x3

        % ---- Newton–Raphson update ----
        dq = J_inv * e;  % 4x1
        q  = q + dq;
    end

    % If we exit the loop, we did not converge
    warning('inverse_kinematics_func:MaxIter', ...
        'Maximum iterations reached without full convergence.');

end
