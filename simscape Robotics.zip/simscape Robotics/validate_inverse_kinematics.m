% ---------------------------------------------------------
% VALIDATION SCRIPT FOR INVERSE KINEMATICS (Milestone 03)
% ---------------------------------------------------------
clear; clc; close all;

disp('==============================================');
disp('        VALIDATION OF INVERSE KINEMATICS       ');
disp('==============================================');

%% 1. Robot link lengths (same as FK & IK)
L1 = 43.55;
L2 = 140;
L3 = 134;
L4 = 70;

%% 2. DH builder
buildDH = @(q) [ ...
    (-pi/2 + q(1))  L1  0   -pi/2;  
    (-pi/2 + q(2))   0  L2   0;     
    (q(3))           0  L3   0;     
    (q(4))           0  L4   0 ];

%% 3. Choose a desired target position (REACHABLE)
% You can change these values to anything reachable
X_des = [200; 50; 150];   % mm OR meters, must match your FK units

disp('Desired End-Effector Target Position (X_des):');
disp(X_des');

%% 4. Initial guess for IK
q0_deg = [30;20;-20; 0];
q0 = deg2rad(q0_deg);

%% 5. Solve inverse kinematics numerically
q_sol = inverse_kinematics_func(q0, X_des);

disp('----------------------------------------------');
disp('Joint Angles returned by Inverse Kinematics:');
disp(['q1 = ' num2str(rad2deg(q_sol(1))) ' deg']);
disp(['q2 = ' num2str(rad2deg(q_sol(2))) ' deg']);
disp(['q3 = ' num2str(rad2deg(q_sol(3))) ' deg']);
disp(['q4 = ' num2str(rad2deg(q_sol(4))) ' deg']);
disp('----------------------------------------------');

%% 6. Validate using Forward Kinematics
DH_sol = buildDH(q_sol);
[X_fk, ~] = forward_kinematics_func_num(DH_sol);

disp('End-Effector Position Calculated via FK:');
disp(X_fk');

%% 7. Compute the error between desired and achieved
pos_error = X_des - X_fk;

disp('----------------------------------------------');
disp('Position Error (X_des - X_fk):');
disp(pos_error');
disp('----------------------------------------------');

%% 8. Instructions for Simscape Multibody Validation
disp(' ');
disp('NOW VALIDATE IN SIMSCAPE MULTIBODY:');
disp('1. Open your Simscape robot model.');
disp('2. Set the joint angles to the values q_sol above.');
disp('3. Use a Transform Sensor to measure the end-effector position.');
disp('4. The measured position MUST match X_des (within small error).');
disp(' ');
disp('==============================================');
disp('    Numerical Validation Completed (FK OK)     ');
disp('==============================================');
