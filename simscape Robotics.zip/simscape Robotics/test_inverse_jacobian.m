% ---------------------------------------------------------
% Test Script for inverse_jacobian_matrix(q)
% ---------------------------------------------------------

clear; clc; close all;

% Example joint angles (in degrees)
q_deg = [20; 10; -15; 5];

% Convert to radians
q = deg2rad(q_deg);

% Display test header
disp('----------------------------------------');
disp(' Testing inverse_jacobian_matrix(q) ');
disp('----------------------------------------');
fprintf('Input joint angles (deg):  [%.1f  %.1f  %.1f  %.1f]\n', q_deg);
fprintf('Input joint angles (rad):  [%.4f  %.4f  %.4f  %.4f]\n\n', q);

% Call your function
J_inv = inverse_jacobian_matrix(q);

% Display the output
disp('Inverse Jacobian (pseudo-inverse) J^{-1}:');
disp(J_inv);

% Check size
fprintf('\nMatrix size = %d x %d (expected 4 x 3)\n', size(J_inv,1), size(J_inv,2));

disp('----------------------------------------');
disp(' Test complete.');
disp('----------------------------------------');
