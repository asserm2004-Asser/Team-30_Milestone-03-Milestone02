function J_inv = inverse_jacobian_matrix(q)
% -----------------------------------------------------------
% Computes the pseudo-inverse Jacobian of the 4-DOF robotic arm
% q : [4x1] vector of joint angles (radians)
% Returns J_inv : pseudo-inverse of the Jacobian (4x3)
% -----------------------------------------------------------

    % Step 1: Robot link lengths
    L1 = 43.55;
    L2 = 140;
    L3 = 134;
    L4 = 70;

    % Step 2: DH builder function
    buildDH = @(q) [ ...
        (-pi/2 + q(1))  L1  0   -pi/2;
        (-pi/2 + q(2))   0  L2   0;
        (q(3))           0  L3   0;
        (q(4))           0  L4   0 ];

    % Step 3: Compute original FK
    DH = buildDH(q);
    [X0, ~] = forward_kinematics_func_num(DH);

    % Step 4: Numerical differentiation
    n = length(q);
    h = 1e-6;
    J = zeros(3, n);

    for i = 1:n
        dq = zeros(n,1);
        dq(i) = h;

        DH_new = buildDH(q + dq);
        [X_new, ~] = forward_kinematics_func_num(DH_new);

        J(:,i) = (X_new - X0) / h;
    end

    % Step 5: compute pseudo inverse
    J_inv = pinv(J);

end
