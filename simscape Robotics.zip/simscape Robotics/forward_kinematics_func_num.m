function [X, T0n, Tall] = forward_kinematics_func_num(DH)
% Numeric forward kinematics from DH table
% DH is an Nx4 matrix: [theta, d, a, alpha]
% Returns end-effector position X = [x; y; z]

n = size(DH,1);
T0n = eye(4);
Tall = cell(1,n);

for i = 1:n
    th = DH(i,1); 
    d  = DH(i,2); 
    a  = DH(i,3); 
    al = DH(i,4);
    Ti = transformation_func(th,d,a,al);
    T0n = T0n * Ti;
    Tall{i} = T0n;
end

X = T0n(1:3,4);
end
